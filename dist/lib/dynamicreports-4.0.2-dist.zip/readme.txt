DynamicReports
-----------------------------------


http://www.dynamicreports.org


DynamicReports is an open source Java reporting library based on JasperReports. 
It allows to create dynamic report designs and it doesn't need a visual report designer. 
You can very quickly create reports and produce documents that can be displayed, 
printed or exported into many popular formats such as PDF, Excel, Word and others.


